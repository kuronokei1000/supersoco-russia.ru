<?
$MESS["SPS_TITLE_ACCOUNT"] = "Mein Guthaben";
$MESS["SPS_CHAIN_ACCOUNT"] = "Interner Account";
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_BUY_MONEY"] = "Guthaben aufladen";
?>