<?
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_CHAIN_ORDERS"] = "Meine Bestellungen";
?>