<?php
$MESS["SPS_CHAIN_MAIN"] = "Мой кабинет";
$MESS["SPS_CHAIN_SUBSCRIBE"] = "Список подписок пользователя";
$MESS["SPS_TITLE_SUBSCRIBE"] = "Мои подписки";
$MESS["SPS_CHAIN_SUBSCRIBE_NEW"] = "Ваши подписки";