<?
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_CHAIN_PROFILE"] = "User profiles";
$MESS["SPS_TITLE_PROFILE"] = "User profile";
?>