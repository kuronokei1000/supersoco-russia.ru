<?
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_CHAIN_ORDERS"] = "Meine Bestellungen";
$MESS["SPS_CHAIN_ORDER_DETAIL"] = "Bestellung ##ID# stornieren";
?>