<?
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_CHAIN_PRIVATE"] = "Persцnliche Informationen";
$MESS["SPS_TITLE_PRIVATE"] = "Persцnliche Informationen";
?>