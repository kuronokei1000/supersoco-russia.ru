<?
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2023-01-24 00:00:00"
);
?>