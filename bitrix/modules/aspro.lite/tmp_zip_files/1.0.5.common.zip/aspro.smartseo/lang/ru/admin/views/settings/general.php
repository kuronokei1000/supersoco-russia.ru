<?
$MESS['SMARTSEO_PAGE_TITLE'] = 'Настройки общие';

$MESS['SMARTSEO_FORM_ENTITY_ID'] = 'ID';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_TABLE'] = 'Кеширование таблиц модуля';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_TEMPLATE_ENTITY'] = 'Кеширование результата SEO шаблонов';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_CONDITION_CONTROL'] = 'Кеширование результата компонента условий';
$MESS['SMARTSEO_FORM_CLEAN_CACHE'] = 'Принудительный сброс кеша';
$MESS['SMARTSEO_FORM_ENTITY_FILTER_RULE_NAME_TEMPLATE'] = 'Названия правила по умолчанию';
$MESS['SMARTSEO_FORM_ENTITY_FILTER_RULE_IS_ONLY_CATALOG'] = 'Использовать только инфоблоки торгового каталога';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_META_TAGS'] = 'Замена мета тегов';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_TITLE'] = 'Замена заголовка страницы';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_SNIPPET'] = 'Замена сниппетов';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_URL'] = 'Замена ссылок в интерфейсе компонента bitrix:catalog';

$MESS['SMARTSEO_FORM_HINT_ID'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_TABLE'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_TEMPLATE_ENTITY'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_CONDITION_CONTROL'] = '';
$MESS['SMARTSEO_FORM_HINT_FILTER_RULE_NAME_TEMPLATE'] = '';
$MESS['SMARTSEO_FORM_HINT_FILTER_RULE_IS_ONLY_CATALOG'] = '';
$MESS['SMARTSEO_FORM_HINT_PAGE_IS_REPLACE_SNIPPET'] = '';
$MESS['SMARTSEO_FORM_HINT_PAGE_IS_REPLACE_URL'] = 'Замена «Стандартный URL» на «Новый URL» в интерфейсе компонента bitrix:catalog';

$MESS['SMARTSEO_TAB_SETTINGS_NAME'] = 'Настройки';
$MESS['SMARTSEO_TAB_SETTINGS_TITLE'] = 'Общие настройки';

$MESS['SMARTSEO_FORM_BTN_APPLY'] = 'Применить';
$MESS['SMARTSEO_FORM_BTN_CANCEL'] = 'Отмена';
$MESS['SMARTSEO_FORM_BTN_CLEAN_CACHE'] = 'Выполнить сброс кеша';

$MESS['SMARTSEO_FORM_HINT_APPLY'] = 'Сохранить и остаться в форме';
$MESS['SMARTSEO_FORM_HINT_CANCEL'] = 'Не сохранять и вернуться';

$MESS['SMARTSEO_FORM_GROUP_CACHE'] = 'Настройки кеширования';
$MESS['SMARTSEO_FORM_GROUP_FILTER_RULE'] = 'Настройки правил фильтра';
$MESS['SMARTSEO_FORM_GROUP_GENERATE'] = 'Настройки генерации ЧПУ';
$MESS['SMARTSEO_FORM_GROUP_PAGE'] = 'Настройки публичной части';

$MESS['SMARTSEO_MESSAGE_CLEAR_CACHE_SUCCESS'] = 'Сброс кеша выполнен успешно';
$MESS['SMARTSEO_NOTIFICATION_CLEAR_CACHE_SUCCESS'] = '<div class = "aspro-ui-notification"> <h4> Cброс кеша </h4> Принудительный сброс кеша выполнен успешно </div>';

$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_SET_CANONICAL'] = 'Устанавливать canonical';