<?
$MESS['SMARTSEO_PAGE_TITLE'] = 'General Settings';

$MESS['SMARTSEO_FORM_ENTITY_ID'] = 'ID';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_TABLE'] = 'Caching Module Tables';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_TEMPLATE_ENTITY'] = 'SEO Template Result Caching';
$MESS['SMARTSEO_FORM_ENTITY_CACHE_CONDITION_CONTROL'] = 'Caching the result of a condition component';
$MESS['SMARTSEO_FORM_ENTITY_FILTER_RULE_NAME_TEMPLATE'] = 'Default Rule Names';
$MESS['SMARTSEO_FORM_CLEAN_CACHE'] = 'Force cache reset';
$MESS['SMARTSEO_FORM_ENTITY_FILTER_RULE_IS_ONLY_CATALOG'] = 'Use only information blocks of the trade catalog';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_META_TAGS'] = 'Replacing Meta Tags';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_TITLE'] = 'Replace Page Title';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_SNIPPET'] = 'Replace Snippets';
$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_REPLACE_URL'] = 'Replacing links in the interface of the bitrix component: catalog';

$MESS['SMARTSEO_FORM_HINT_ID'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_TABLE'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_TEMPLATE_ENTITY'] = '';
$MESS['SMARTSEO_FORM_HINT_CACHE_CONDITION_CONTROL'] = '';
$MESS['SMARTSEO_FORM_HINT_FILTER_RULE_NAME_TEMPLATE'] = '';
$MESS['SMARTSEO_FORM_HINT_FILTER_RULE_IS_ONLY_CATALOG'] = '';
$MESS['SMARTSEO_FORM_HINT_PAGE_IS_REPLACE_SNIPPET'] = '';
$MESS['SMARTSEO_FORM_HINT_PAGE_IS_REPLACE_URL'] = 'Replacing "Standard URL" with "New URL" in the interface of the bitrix component: catalog';

$MESS['SMARTSEO_TAB_SETTINGS_NAME'] = 'Settings';
$MESS['SMARTSEO_TAB_SETTINGS_TITLE'] = 'General Settings';

$MESS['SMARTSEO_FORM_BTN_APPLY'] = 'Apply';
$MESS['SMARTSEO_FORM_BTN_CANCEL'] = 'Cancel';
$MESS['SMARTSEO_FORM_BTN_CLEAN_CACHE'] = 'Reset cache';

$MESS['SMARTSEO_FORM_HINT_APPLY'] = 'Save and Stay Fit';
$MESS['SMARTSEO_FORM_HINT_CANCEL'] = 'Do not save and return';

$MESS['SMARTSEO_FORM_GROUP_CACHE'] = 'Caching Settings';
$MESS['SMARTSEO_FORM_GROUP_FILTER_RULE'] = 'Filter Rule Settings';
$MESS['SMARTSEO_FORM_GROUP_GENERATE'] = 'CNC Generation Settings';
$MESS['SMARTSEO_FORM_GROUP_PAGE'] = 'Public Part Settings';

$MESS['SMARTSEO_MESSAGE_CLEAR_CACHE_SUCCESS'] = 'The cache was flushed successfully';
$MESS['SMARTSEO_NOTIFICATION_CLEAR_CACHE_SUCCESS'] = '<div class = "aspro-ui-notification"> <h4> Reset cache </h4> Forced cache reset completed successfully </div>';

$MESS['SMARTSEO_FORM_ENTITY_PAGE_IS_SET_CANONICAL'] = 'Set canonical';