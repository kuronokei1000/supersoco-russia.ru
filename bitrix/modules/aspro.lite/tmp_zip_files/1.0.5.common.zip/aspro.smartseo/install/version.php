<?
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2023-06-29 00:00:00"
);
?>