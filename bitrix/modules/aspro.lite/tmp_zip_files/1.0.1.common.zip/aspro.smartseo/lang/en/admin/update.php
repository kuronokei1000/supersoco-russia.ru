<?
$MESS['ASPRO_MAX_PAGE_TITLE'] = 'Smart SEO module update';
$MESS['ASPRO_SMARTSEO_INSTALL'] = 'Install Smart SEO';
$MESS['ASPRO_SMARTSEO_CHECK'] = 'Check';
$MESS['ASPRO_SMARTSEO_CLEAR'] = 'Preparing archive (deleting unnecessary files)';
$MESS["ASPRO_SMARTSEO_DOWNLOAD"] = "Archive preparation (download)";
$MESS['ASPRO_SMARTSEO_DOWNLOAD_PART'] = 'Preparing archive (loading #INDEX# from #MAX_INDEX#, passed #TMP_SIZE# from #FILE_SIZE#)';
$MESS['ASPRO_SMARTSEO_UNZIP'] = 'Preparing archive (unpacking)';
$MESS['ASPRO_SMARTSEO_UNZIP_PART'] = 'Preparing archive (unpacking #INDEX# from #MAX_INDEX#)';
$MESS['ASPRO_SMARTSEO_COPY'] = 'Copying files';
$MESS['ASPRO_SMARTSEO_SETUP'] = 'Setup';
$MESS['ASPRO_SMARTSEO_ERROR'] = 'Error';
$MESS['ASPRO_SMARTSEO_FINISH'] = 'Installation completed';
$MESS['ASPRO_SMARTSEO_DELETE_FINISH'] = 'Deletion completed';
$MESS['ASPRO_SMARTSEO_ERROR_SETUP_INDEX'] = 'Module setup file not found';
$MESS['ASPRO_SMARTSEO_OPTIONS_LINK'] = 'Go to Smart SEO module settings';
$MESS['ASPRO_SMARTSEO_ALREADY_INSTALLED'] = 'Smart SEO installed';
$MESS['ASPRO_SMARTSEO_CAN_DELETE'] = 'You can delete the Smart SEO module';
$MESS['ASPRO_SMARTSEO_BUTTON_DELETE'] = 'Delete';
$MESS['ASPRO_SMARTSEO_BUTTON_DOWNLOAD'] = 'Install updates';
$MESS['ASPRO_SMARTSEO_CAN_DOWNLOAD'] = 'Press button to update module';
$MESS['ASPRO_SMARTSEO_CLEAR_FINAL'] = 'Delete temporary files';
$MESS['ASPRO_SMARTSEO_UPDATES_AVAILABLE'] = "Updates available: #COUNT_UPDATES#";
$MESS['ASPRO_SMARTSEO_NO_UPDATES_AVAILABLE'] = 'No updates available';
$MESS['ASPRO_SMARTSEO_CHECK_UPDATES_AVAIBLE'] = 'Check for available updates';
$MESS['ASPRO_SMARTSEO_UPDATE_TAB'] = 'Updates';
$MESS['ASPRO_SMARTSEO_UPDATE_TAB_TITLE'] = 'Updates';
$MESS['ASPRO_SMARTSEO_UPDATE_OBF_FILES_ERROR'] = 'Attention! We found that the permissions on the system files of the Aspro: Smart SEO module were reset. There may be problems getting module updates. <a href="https://aspro.ru/kb/article/433/">More</a>.';
?>