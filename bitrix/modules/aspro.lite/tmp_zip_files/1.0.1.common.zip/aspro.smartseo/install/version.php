<?
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2022-10-25 00:00:00"
);
?>