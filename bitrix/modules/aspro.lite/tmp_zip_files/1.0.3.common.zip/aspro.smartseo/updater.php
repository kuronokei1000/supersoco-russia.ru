<?
// aspro.smartseo 1.0.3 updater
// changed files

// module:
// /admin/menu.php - update
// /lang/en/admin/menu.php - update
// css:

// js:

// components:
// 

// wizard:


// template:
// 

// public:
// 



use \Bitrix\Main\Config\Option;

require_once __DIR__ . '/functions.php';

define('PARTNER_NAME', 'aspro');
define('MODULE_NAME', 'aspro.smartseo');
define('MODULE_NAME_SHORT', 'smartseo');
define('TEMPLATE_NAME', 'aspro_smartseo');
define('MODULE_PATH', '/bitrix/modules/' . MODULE_NAME);
define('COMPONENT_PATH', '/bitrix/components/' . PARTNER_NAME);
define('ADMIN_JS_PATH', '/bitrix/js/' . MODULE_NAME);
define('ADMIN_CSS_PATH', '/bitrix/css/' . MODULE_NAME);
define('TEMPLATE_PATH', '/bitrix/templates/' . TEMPLATE_NAME);
define('UPDATER_SELF_TEMPLATE_PATH', 'install/wizards/' . PARTNER_NAME . '/' . MODULE_NAME_SHORT . '/site/templates/' . TEMPLATE_NAME);
define('UPDATER_SITE_TEMPLATE_PATH', 'templates/' . TEMPLATE_NAME);
define('CURRENT_VERSION', GetCurVersion($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/' . MODULE_NAME . '/install/version.php'));
define('NEW_VERSION', GetCurVersion(__DIR__ . '/install/version.php'));

UpdaterLog('START UPDATE ' . CURRENT_VERSION . ' -> ' . NEW_VERSION . PHP_EOL);


// remove old bak files
RemoveOldBakFiles();

// create bak files
foreach ([
	// module
	MODULE_PATH.'/admin/menu.php',
    MODULE_PATH.'/lang/en/admin/menu.php',

	// js
	//ADMIN_JS_PATH .'/notice.js',

	// catalog
	//COMPONENT_PATH.'/catalog.delivery.max/templates/.default/script.js',

	// template
	//TEMPLATE_PATH.'/components/aspro/com.banners.max/top_big_banner_2/style.css',

] as $file) {
	CreateBakFile($_SERVER['DOCUMENT_ROOT'] . $file);
}

//UpdaterLog('TEMPLATE_PATH ' . TEMPLATE_PATH);

// update module
//$updater->CopyFiles('install', 'modules/' . MODULE_NAME . '/install');

// update admin section images
//$updater->CopyFiles('install/images', 'images/'.MODULE_NAME);

// update admin section gadget
// $updater->CopyFiles('install/gadgets', 'gadgets');

// update admin page
// $updater->CopyFiles('install/admin', 'admin');

// update admin js
//$updater->CopyFiles('install/js', 'js/'.MODULE_NAME.'/');

// update admin css
//$updater->CopyFiles('install/css', 'css/' . MODULE_NAME . '/');

// update admin tools
// $updater->CopyFiles('install/tools', 'tools/'.MODULE_NAME.'/');

// for actual theme.less
// $updater->CopyFiles('css', 'modules/'.MODULE_NAME.'/css');

// update wizard
//$updater->CopyFiles('install/wizards', 'wizards');

// update components
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/bitrix/components/' . PARTNER_NAME . '/')) {
	//$updater->CopyFiles('install/components', 'components');
}


// current SITEs
// $arSites = GetSites();

// current IBLOCK_IDs
// $arIblocks = GetIBlocks();


// if (IsModuleInstalled(MODULE_NAME)) {
// 	UnRegisterModuleDependences("iblock", "OnAfterIBlockElementDelete", MODULE_NAME, "CMaxCache", "DoIBlockElementAfterDelete");
// }

// is composite enabled
$compositeMode = IsCompositeEnabled();

// clear all sites cache in some components and dirs (include composite cache)
ClearAllSitesCacheDirs([
	'html_pages',
	'cache/js',
	'cache/css'
]);

ClearAllSitesCacheComponents([
	// PARTNER_NAME.':catalog.delivery.max',
	// 'bitrix:catalog.element',
]);

if ($compositeMode) {
	$arHTMLCacheOptions = GetCompositeOptions();
	EnableComposite($compositeMode === 'AUTO_COMPOSITE', $arHTMLCacheOptions);
}

UpdaterLog('FINISH UPDATE ' . CURRENT_VERSION . ' -> ' . NEW_VERSION . PHP_EOL);
